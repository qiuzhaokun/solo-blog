title: 我在 GitHub 上的开源项目
date: '2019-08-15 14:58:39'
updated: '2019-08-15 14:58:39'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [jianji_api](https://github.com/qiuzhaokun/jianji_api) <kbd title="主要编程语言">PHP</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/qiuzhaokun/jianji_api/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/qiuzhaokun/jianji_api/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/qiuzhaokun/jianji_api/network/members "分叉数")</span>

简记API服务



---

### 2. [baseService](https://github.com/qiuzhaokun/baseService) <kbd title="主要编程语言">PHP</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/qiuzhaokun/baseService/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/qiuzhaokun/baseService/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/qiuzhaokun/baseService/network/members "分叉数")</span>

基础服务

